package aquarium.entities.fish.classes;

public class SaltwaterFish extends BaseFish{
    private static final int INITIAL_SIZE = 5;

    public SaltwaterFish(String name, String species, double price) {
        super(name, species, price);
    }

    @Override
    public int getSize() {
        return INITIAL_SIZE;
    }

    @Override
    public void eat() {

    }
}
