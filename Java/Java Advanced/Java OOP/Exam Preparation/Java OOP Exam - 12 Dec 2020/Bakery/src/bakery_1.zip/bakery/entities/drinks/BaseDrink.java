package bakery.entities.drinks;

import bakery.entities.drinks.interfaces.Drink;

public class BaseDrink implements Drink {
    private String name;
    private int portion;
    private double price;
    private String brand;

    protected BaseDrink(String name, int portion, double price, String brand) {
        this.setName(name);
        this.setPortion(portion);
        this.setPrice(price);
        this.setBrand(brand);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPortion(int portion) {
        this.portion = portion;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    //    • name - String
    //        ◦ If the name is null or whitespace,
    //        throw an IllegalArgumentException with message "Name cannot be null or white space!"
    //    • portion - int
    //        ◦ If the portion is less or equal to 0,
    //        throw an IllegalArgumentException with message "Portion cannot be less or equal to zero!"
    //    • price - double
    //        ◦ If the portion is less or equal to 0,
    //        throw an IllegalArgumentException with message "Price cannot be less or equal to zero!"
    //    • brand - String
    //        ◦ If the name is null or whitespace,
    //        throw an IllegalArgumentException with message "Brand cannot be null or white space!"

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getPortion() {
        return portion;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public String getBrand() {
        return brand;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
