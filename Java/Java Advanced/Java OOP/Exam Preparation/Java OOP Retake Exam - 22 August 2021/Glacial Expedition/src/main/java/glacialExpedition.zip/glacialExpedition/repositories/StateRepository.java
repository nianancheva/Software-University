package glacialExpedition.repositories;

import glacialExpedition.models.states.State;

import java.util.ArrayList;
import java.util.Collection;

public class StateRepository<T extends State> implements Repository<T>{
    private Collection<State> states;

    public StateRepository() {
        states = new ArrayList<>();
    }


    @Override
    public Collection<T> getCollection() {
        return null;
    }

    @Override
    public void add(State entity) {

    }

    @Override
    public boolean remove(State entity) {
        return false;
    }

    @Override
    public T byName(String name) {
        return null;
    }
}
