package glacialExpedition.models.states;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class StateImpl implements State{
    private String name;
    private Collection<String> exhibits;

    public StateImpl(String name) {
        this.setName(name);
        exhibits = new ArrayList<>();
    }

    private void setName(String name) {
        this.name = name;
    }

    @Override
    public Collection<String> getExhibits() {
        return Collections.unmodifiableCollection(exhibits);
    }

    @Override
    public String getName() {
        return name;
    }
}
