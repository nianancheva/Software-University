package restaurant.common.enums;

public enum BeveragesType {
    Smoothie,
    Fresh
}
